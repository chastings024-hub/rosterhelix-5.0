"""RosterHelix 5.0E research diagnostics. Does not affect live projections.

Ablations are predefined, not optimized on evaluation data. All predictions are
walk-forward: only games strictly before the evaluated week are used.
"""
from collections import defaultdict
from statistics import mean
from random import Random
from math import sqrt
from rh_model_d3 import candidate_projection, _fantasy

VERSION = '5.0E-ablation-v1'
RECIPES = ('production', 'd3_candidate', 'no_matchup', 'recent_only', 'season_only', 'opportunity_35', 'opportunity_65')

def _clip(x):
    return round(max(0.0, float(x)), 2)

def _predictions(prior, base, scoring):
    multiplier = float(base.get('opponent_multiplier') or 1.0)
    baseline_unadjusted = (float(base['projected_points']) / multiplier) if multiplier else float(base['projected_points'])
    season = float(base['season_ppg'])
    recent = float(base['recent_ppg'])
    n = len(prior)
    w = 0.35 * min(1.0, n / 5)
    form = (1 - w) * season + w * recent
    opportunity = base.get('opportunity') or {}
    opp = opportunity.get('estimated_points')
    if opp is None:
        opp = form
    return {
        'production': _clip(base['projected_points']),
        'd3_candidate': candidate_projection(prior, scoring, base),
        'no_matchup': _clip(baseline_unadjusted),
        'recent_only': _clip(recent * multiplier),
        'season_only': _clip(season * multiplier),
        'opportunity_35': _clip((.65 * form + .35 * float(opp)) * multiplier),
        'opportunity_65': _clip((.35 * form + .65 * float(opp)) * multiplier),
    }

def evaluate_ablation(conn, years, scoring, projection_fn, limit=1000, min_prior=3):
    if scoring not in ('ppr', 'half', 'standard'):
        raise ValueError('Unsupported scoring')
    if not years or len(years)>4 or len(set(years))!=len(years) or any(y<2000 or y>2100 for y in years):
        raise ValueError('Choose 1–4 distinct seasons')
    if not 100<=limit<=3000:
        raise ValueError('Limit must be 100–3000 per season')
    records=[]; per_season={}; per_position={}
    for year in years:
        samples=[]
        games=conn.execute("SELECT * FROM player_games WHERE season=? AND pos IN ('RB','WR','TE') AND week>=4 ORDER BY week,player LIMIT ?",(year,limit)).fetchall()
        for game in games:
            week=int(game['week']); name=game['player']
            prior=conn.execute('SELECT * FROM player_games WHERE season=? AND player=? AND week<? ORDER BY week DESC',(year,name,week)).fetchall()
            if len(prior)<min_prior: continue
            try:
                base=projection_fn(conn,name,year,scoring,(game['opponent'] or '').upper(),before_week=week)
                predicted=_predictions(prior,base,scoring)
            except (ValueError,TypeError,KeyError,ZeroDivisionError):
                continue
            sample={'season':year,'week':week,'position':game['pos'],'actual':_fantasy(game,scoring),'predicted':predicted}
            samples.append(sample)
        records.extend(samples)
        per_season[str(year)]=_metrics(samples)
    for pos in ('RB','WR','TE'):
        per_position[pos]=_metrics([r for r in records if r['position']==pos])
    all_metrics=_metrics(records)
    robustness=_robustness(records)
    ranked=sorted(({'recipe':key,**value} for key,value in all_metrics['recipes'].items()),key=lambda x:x['mae'] if x['mae'] is not None else float('inf'))
    return {'version':VERSION,'scoring':scoring,'seasons':years,'scan_limit_per_season':limit,
            'summary':all_metrics,'by_season':per_season,'by_position':per_position,
            'ranked_recipes':ranked,'robustness':robustness,'production_model_unchanged':True,
            'promotion_recommendation':'no_automatic_promotion',
            'methodology':'Each game is predicted using only prior games from the same season; all recipes share identical eligible player-games. Predefined component ablations isolate recency, opportunity blend, and matchup effects. Lower MAE is better.',
            'limitations':['Exploratory ablations, not trained models or a season-held-out model selection procedure',
                           'Week-cluster bootstrap is descriptive and does not eliminate selection bias or data leakage from prior human tuning',
                           'Season selection and recipe inspection may introduce human selection bias',
                           'Input scan limit truncates the set of eligible games; raise limit for broader coverage',
                           'Only active RB/WR/TE games with >=3 prior recorded games; absences are not evaluated',
                           'No verified snaps, routes, carries, injuries, coverage schemes or weather data',
                           'No calibrated win probabilities or automatic promotion']}

def _metrics(rows):
    if not rows:
        return {'n':0,'recipes':{name:{'mae':None,'bias':None,'delta_vs_production':None} for name in RECIPES}}
    base_mae=mean(abs(r['predicted']['production']-r['actual']) for r in rows)
    data={}
    for recipe in RECIPES:
        mae=mean(abs(r['predicted'][recipe]-r['actual']) for r in rows)
        bias=mean(r['predicted'][recipe]-r['actual'] for r in rows)
        data[recipe]={'mae':round(mae,3),'bias':round(bias,3),'delta_vs_production':round(base_mae-mae,3)}
    return {'n':len(rows),'recipes':data}


def _robustness(rows, repetitions=400):
    """Paired error deltas, week-block resampling, and chronological stability.

    A block is a (season, week), not an individual player-game, to reduce
    false confidence from shared matchup and week conditions. Reproducible RNG.
    These are descriptive uncertainty intervals, not a model-selection license.
    """
    if not rows:
        return {'n': 0, 'status': 'insufficient_data', 'recipes': {}}
    groups = defaultdict(list)
    for r in rows:
        groups[(r['season'], r['week'])].append(r)
    blocks = list(groups.values())
    rng = Random(5002)
    result = {}
    for recipe in RECIPES:
        if recipe == 'production':
            continue
        def delta(r):
            return abs(r['predicted']['production'] - r['actual']) - abs(r['predicted'][recipe] - r['actual'])
        diffs = [delta(r) for r in rows]
        boot = []
        if len(blocks) >= 5:
            for _ in range(repetitions):
                selected = [blocks[rng.randrange(len(blocks))] for _ in range(len(blocks))]
                ds = [delta(r) for block in selected for r in block]
                boot.append(mean(ds))
            boot.sort()
        ordered = sorted(rows, key=lambda r: (r['season'], r['week']))
        midpoint = len(ordered)//2
        early, late = ordered[:midpoint], ordered[midpoint:]
        by_season = {}
        for year in sorted({r['season'] for r in rows}):
            subset = [r for r in rows if r['season'] == year]
            by_season[str(year)] = round(mean(delta(r) for r in subset), 3)
        result[recipe] = {
            'delta_mae': round(mean(diffs), 3),
            'bootstrap_95_interval': [round(boot[int(.025 * (len(boot)-1))],3),round(boot[int(.975 * (len(boot)-1))],3)] if boot else None,
            'early_half_delta': round(mean(delta(r) for r in early), 3) if early else None,
            'late_half_delta': round(mean(delta(r) for r in late), 3) if late else None,
            'season_deltas': by_season,
            'improved_every_season': bool(by_season) and all(v > 0 for v in by_season.values()),
            'interval_entirely_positive': bool(boot) and boot[int(.025*(len(boot)-1))] > 0,
        }
    return {'n':len(rows), 'week_blocks':len(blocks), 'bootstrap_repetitions':repetitions,
            'interval_method':'paired season-week block bootstrap, fixed random seed',
            'interpretation':'Positive delta means lower MAE than production; intervals describe sampling variation, not out-of-sample model validity.',
            'recipes':result,
            'promotion_gate':'not_eligible_without_pre_registered_season_held_out_test'}
